# Magic Math Sisters

Lernspiel (Jump'n'Run) zu Differentialgleichungen – läuft direkt im Browser, am PC und auf dem Smartphone.

**Spielen:** `index.html` im Browser öffnen – oder über GitHub Pages (siehe unten).

## Dateien

| Datei | Inhalt |
|---|---|
| `index.html` | das komplette Spiel (Grafik, Musik, Level) |
| `questions.js` | **die Mathefragen – hier bearbeiten** |
| `README.md` | diese Anleitung |
| `assets/` | ältere Grafiken; werden vom Spiel nicht mehr benötigt, können aber bleiben |

## Fragen ändern

Die Datei `questions.js` mit einem beliebigen Texteditor öffnen (auf GitHub: Datei anklicken → Stift-Symbol).
Jede Frage hat dieses Format:

```js
{type:'Rechnen',
 q:'Löse \\(y^{\\prime}=-y,\\ y(0)=1\\).',
 a:['\\(e^{t}\\)','\\(e^{-t}\\)','\\(1-t\\)','\\(t\\)'],
 ok:1,                      // 0 = erste Antwort, 1 = zweite, 2 = dritte, 3 = vierte
 why:'\\(y=Ce^{-t}\\), und aus \\(y(0)=1\\) folgt \\(C=1\\).'},
```

* Formeln stehen in `\\( ... \\)`; jeder Backslash wird **doppelt** geschrieben.
* Die Fragen kommen der Reihe nach dran. Mit `shuffle: true` in `MMS_SETTINGS` werden sie gemischt.
* Das Spiel hat 16 Σ-Kisten und mindestens 3 Drachenfragen. Ab 19 Fragen wiederholt sich keine.

## So funktionieren die Fragen im Spiel

* **Σ-Kisten** (lila) von unten anstoßen → Frage erscheint. Jede Kiste hat **einen** Versuch.
* **Richtig:** Kiste wird **grün**, ein Frosch springt heraus und bringt **ein Extraleben**.
* **Falsch:** Kiste wird **rot**, die richtige Antwort und eine Erklärung werden gezeigt – sonst keine Folgen.
* Im Fluss-Level repariert die Σ-Kiste am Ufer immer die Brücke.
* Beim **Drachen** löst jeder Treffer eine Frage aus. Nur richtige Antworten verletzen ihn.
* Oben in der Anzeige sieht man für jede Kiste des Levels ein Kästchen: grau = offen, grün = richtig, rot = falsch.

## Bonussystem

* **Perfektes Level** (alle Σ-Kisten des Levels richtig): +5000 Punkte und ein ★.
* **Alles richtig** (jede Kiste in allen drei Welten + alle Drachenfragen): +50000 Punkte, die **Bonuswelt „Sternenhimmel“** wird freigeschaltet, und am Ende gibt es den Titel *Meister der Mathematik*.
* Man kann jederzeit zurücklaufen, um ausgelassene Kisten noch zu öffnen.

## Steuerung

| | Tastatur | Smartphone |
|---|---|---|
| Laufen | ← → | Steuerkreuz |
| Springen | Leertaste / ↑ | A |
| Rennen & Feuerball | Shift / X | B |
| Ins Rohr | ↓ | Steuerkreuz unten |
| Schwester wechseln | E | SCHWESTER |
| Pause | Enter | START |
| Musik an/aus | M | ♪ MUSIK |
| Effekte an/aus | N | ◀) EFFEKTE |

Helga läuft schneller, Emmy springt höher.

## Auf GitHub Pages veröffentlichen

1. `index.html`, `questions.js` und `README.md` ins Hauptverzeichnis des Repositorys legen.
2. Auf GitHub: **Settings → Pages → Source: Deploy from a branch → main / (root) → Save**.
3. Nach ca. einer Minute ist das Spiel unter `https://elmoppinho.github.io/magic-math-sisters/` spielbar.

Für die Formeldarstellung (MathJax) und die Schriften braucht der Browser eine Internetverbindung. Offline werden die Formeln als einfacher Text angezeigt.

## Musik

Alle Stücke sind gemeinfrei (die Komponisten sind seit über 100 Jahren tot) und wurden für dieses Spiel neu als Chiptune arrangiert. Es sind keine Aufnahmen enthalten, daher ist keine Lizenz nötig.

* P. I. Tschaikowsky – *Schwanensee* (Titelbild, Ende)
* W. A. Mozart – *Eine kleine Nachtmusik* (Welt 1-1)
* W. A. Mozart – *Rondo alla Turca* (Welt 1-2)
* L. v. Beethoven – *Für Elise* (Bonusraum)
* E. Grieg – *In der Halle des Bergkönigs* (Welt 1-3, wird im Drachenkampf schneller)
* J. Strauss (Sohn) – *An der schönen blauen Donau* (Bonuswelt)
* L. v. Beethoven – *Ode an die Freude* (Level geschafft)

Alle Grafiken sind eigene Pixelart im Code.
